package com.bean;

import java.io.InputStream;

public class UploadBean {
	private String filename, content, enc, key,servername,fid;
	public String getFid() {
		return fid;
	}

	public void setFid(String fid) {
		this.fid = fid;
	}

	public String getServername() {
		return servername;
	}

	public void setServername(String servername) {
		this.servername = servername;
	}

	private InputStream photo1;

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getEnc() {
		return enc;
	}

	public void setEnc(String enc) {
		this.enc = enc;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setPhoto1(InputStream photo1) {
		// TODO Auto-generated method stub
		this.photo1 = photo1;
	}

	public InputStream getPhoto() {
		// TODO Auto-generated method stub
		return photo1;
	}

}
