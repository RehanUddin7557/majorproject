package com.dao;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bean.KeyRecvBean;
import com.bean.UploadBean;
import com.bean.UserBean;
import com.control.ServerBean;

public class Dao {
	public static Connection connect() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/vtjns04_2019", "root", "root");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return con;
	}
	public static int setUser(String sql, UserBean ub) {
		// TODO Auto-generated method stub
		int i = 0;
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, ub.getUsername());
			ps.setString(2, ub.getPassword());
			ps.setString(3, ub.getDob());
			ps.setString(4, ub.getGender());
			ps.setString(5, ub.getEmailid());
			ps.setString(6, ub.getCity());
			ps.setString(7, ub.getAddress());
			ps.setString(8, "pending");
			i = ps.executeUpdate();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public static ResultSet getUserInfo() throws SQLException
	{
		Connection con=connect();
		java.sql.Statement s=con.createStatement();
		ResultSet rs=(ResultSet) s.executeQuery("select * from user");
		return rs;
	}
	public static boolean getData(String sql) {
		// TODO Auto-generated method stub
		boolean b = false;
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			b = rs.next();
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}

	public static String getName(String sql) {
		// TODO Auto-generated method stub
		String name = "";
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				name = rs.getString(1);
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return name;

}
	public static int Server( ServerBean sb) {
		// TODO Auto-generated method stub
		int i = 0;
		Connection con = connect();
		try {
			con=Dao.connect();
			String sql = "insert into server values(?,?,?,?,?,?);";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, sb.getServername());
			ps.setString(2, sb.getPassword());
			ps.setString(3, sb.getDomain());
			ps.setString(5, sb.getEmailid());
			ps.setString(4, sb.getPublishdate());
			ps.setString(6, sb.getCountry());
			i = ps.executeUpdate();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	public static String getServername(String sql)
	{
		
			String name = "";
			Connection con = connect();
			try {
				PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				if(rs.next()){
					name = rs.getString(1);
				}
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return name;
	}
	public static boolean checkUserLogin(String sql2)  {
		Connection con = null;
		int count = 0;
		try {
			con = Dao.connect();
			/* String sql="select * from reg;"; */
			Statement s = con.createStatement();
			ResultSet r = s.executeQuery(sql2);
			while (r.next()) {

				count++;
				// break;

			}
		} catch (SQLException e) {
			// TODO: handle exception
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (count > 0) {
			return true;
		} else {
			return false;
		}

	}	public static int update(String sql) {
		// TODO Auto-generated method stub
		int i = 0;
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			i = ps.executeUpdate();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public static ResultSet getAllusers() throws SQLException {
		List al = new ArrayList();
		String sql = "select * from user where status1='pending'";
	//	String sql = "SELECT  from user   AES_DECRYPT(username,'mykey'),AES_DECRYPT(password,'mykey'),AES_DECRYPT(dob,'mykey'),AES_DECRYPT(gender,'mykey'),AES_DECRYPT(emailid,'mykey'),AES_DECRYPT(city,'mykey'),AES_DECRYPT(address,'mykey') where status1='pending'";
		Connection con = Dao.connect();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		/*while (rs.next()) {

			
				al.add(rs.getString(1));
				al.add(rs.getString(3));al.add(rs.getString(4));al.add(rs.getString(5));al.add(rs.getString(6));al.add(rs.getString(7));al.add(rs.getString(8));
			
		}*/
		return rs;
	}
	public static ResultSet getUserDetails() throws SQLException {
		Connection con = Dao.connect();
		String sql = "select * from user";
		Statement s = con.createStatement();
		ResultSet r = s.executeQuery(sql);
		return r;
	}
	public static boolean updateUser(String s) throws SQLException {
		String sql = "update user set status1='Rejected' where emailid='" + s + "'";
		Connection con = Dao.connect();
		Statement st = con.createStatement();
		boolean f = st.execute(sql);
		System.out.println("boolean is" + f);
		return f;
	}

	public static int setServerreg(String sql, ServerBean sb) {
		// TODO Auto-generated method stub
		int i = 0;
		Connection con = connect();
		try {
			System.out.println("Sreekanth sir");
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, sb.getServername());
			ps.setString(2, sb.getPassword());
			ps.setString(3, sb.getDomain());
			ps.setString(4, sb.getEmailid());
			ps.setString(5, sb.getPublishdate());
			ps.setString(6, sb.getCountry());
			ps.setString(7, "pending");
			i = ps.executeUpdate();
		}catch(Exception e)
		{
			return 0;
		}
		return i;
	}
	public static ResultSet getAllServers() throws SQLException {
		List al = new ArrayList();
		String sql = "select * from serverrequest where approval='pending'";
		Connection con = Dao.connect();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql);
		/*while (rs.next()) {

			
				al.add(rs.getString(1));
				al.add(rs.getString(3));al.add(rs.getString(4));al.add(rs.getString(5));al.add(rs.getString(6));al.add(rs.getString(7));al.add(rs.getString(8));
			
		}*/
		return rs;
	}
	public static ResultSet getServerreg() throws SQLException
	{
		Connection con=connect();
		java.sql.Statement s=con.createStatement();
		ResultSet rs=(ResultSet) s.executeQuery("select * from serverrequest");
		return rs;
	}
	public static ResultSet getData1(String sql) {
		// TODO Auto-generated method stub
		Connection con = connect();
		ResultSet rs = null;
		try{
			PreparedStatement ps = con.prepareStatement(sql);
			rs =  ps.executeQuery();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return rs;
	}
	public static int Register(String sql, ServerBean sb) 
	{
	int i = 0;
	Connection con = connect();
	try {
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, sb.getServername());
		ps.setString(2, sb.getPassword());
		ps.setString(3, sb.getDomain());
		ps.setString(4, sb.getEmailid());
		ps.setString(5, sb.getPublishdate());
		ps.setString(6, sb.getCountry());
		i = ps.executeUpdate();
		ps.close();
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return i;
}
	public static int upload(String sql, UploadBean u) 
	{
		// TODO Auto-generated method stub
			int i = 0;
			Connection con = connect();
			try {
				PreparedStatement ps = con.prepareStatement(sql);
			//	ps.setString(1, u.getFid());
				ps.setString(1, u.getServername());
				ps.setString(2, u.getFilename());
				InputStream photo = u.getPhoto();
				if (photo != null) {
					ps.setBinaryStream(3, photo);
				}
				ps.setString(4, u.getEnc());
				ps.setString(5, u.getContent());
				ps.setString(6, u.getKey());
			
				i = ps.executeUpdate();
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i;
		}
	public static ResultSet getUserUpload() throws SQLException
	{
		Connection con=connect();
		java.sql.Statement s=con.createStatement();
		ResultSet rs=(ResultSet) s.executeQuery("select * from upload");
		return rs;
	}
	public static List<String> getUFile(String sql) {
		// TODO Auto-generated method stub
		List<String> lt = new ArrayList<String>();
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				lt.add(rs.getString(1));
				lt.add(rs.getString(2));
				lt.add(rs.getString(3));
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lt;
	}
	public static ResultSet getServername() throws SQLException
	{
		Connection con=connect();
		java.sql.Statement s=con.createStatement();
		ResultSet rs=(ResultSet) s.executeQuery("select * from upload ");
		return rs;
	}
	public static List<String> getAFiles(String sql) {
		// TODO Auto-generated method stub
		List<String> lt = new ArrayList<String>();
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				lt.add(rs.getString(1));
				lt.add(rs.getString(2));
				lt.add(rs.getString(3));
				lt.add(rs.getString(7));
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lt;
	}
	public static int sendRKeys(String sql, com.bean.KeyRecvBean kb) {
		int i = 0;
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,kb.getEmailid());
			ps.setString(2,kb.getFilename());
			ps.setString(3,kb.getServername());
			ps.setString(4,kb.getFid());
			ps.setString(5,"pending");
			i = ps.executeUpdate();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	public static String getUserkey(String sql) {
		String s = "";
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				s = rs.getString(1);
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	}
	public static List<String> getAkey(String sql) {
		// TODO Auto-generated method stub
		List<String> lt = new ArrayList<String>();
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				lt.add(rs.getString(1));
				lt.add(rs.getString(2));
				lt.add(rs.getString(3));
				lt.add(rs.getString(4));
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lt;
	}
	public static List<String> getOkey(String sql) {
		// TODO Auto-generated method stub
		List<String> lt = new ArrayList<String>();
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				lt.add(rs.getString(1));
				lt.add(rs.getString(2));
				lt.add(rs.getString(3));
				lt.add(rs.getString(4));
			//	lt.add(rs.getString(5));
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lt;
	}
	public static List<String> getOwnerKeys(String sql) {
		// TODO Auto-generated method stub
		List<String> lt = new ArrayList<String>();
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				lt.add(rs.getString(7));
				lt.add(rs.getString(8));
				
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lt;
	}
	public static int sendKeys(String sql, KeyRecvBean kb) {
			int i = 0;
			Connection con = connect();
			try {
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, kb.getFid());
				ps.setString(2, kb.getUserid());
				ps.setString(3, kb.getKey1());
				i = ps.executeUpdate();
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i;
		}
	public static List<String> getOkey1(String sql) {
		// TODO Auto-generated method stub
		List<String> lt = new ArrayList<String>();
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				lt.add(rs.getString(1));
				lt.add(rs.getString(2));
				lt.add(rs.getString(3));
				lt.add(rs.getString(4));
			lt.add(rs.getString(5));
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lt;
	}
	public static List<String> getKeys(String sql) {
		// TODO Auto-generated method stub
		List<String> lt = new ArrayList<String>();
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				lt.add(rs.getString(8));
				lt.add(rs.getString(9));
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lt;
	}
	public static List<String> getUKey(String sql) {
		// TODO Auto-generated method stub
		List<String> lt = new ArrayList<String>();
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				lt.add(rs.getString(3));
				//lt.add(rs.getString(4));
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lt;
	}
	public static List<String> getFid(String sql) {
		// TODO Auto-generated method stub
		List<String> lt = new ArrayList<String>();
		Connection con = connect();
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				lt.add(rs.getString(1));
			}
			rs.close();
			ps.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lt;
	}
	public static ResultSet getUser() throws SQLException
	{
		Connection con=Dao.connect();
		java.sql.Statement s=con.createStatement();
	//	ResultSet r=s.executeQuery("SELECT AES_DECRYPT(username,'mykey'),AES_DECRYPT(password,'mykey'),AES_DECRYPT(dob,'mykey'),AES_DECRYPT(gender,'mykey'),AES_DECRYPT(emailid,'mykey'),AES_DECRYPT(city,'mykey'),AES_DECRYPT(address,'mykey'),status1 FROM USER;");
		//ResultSet r=s.executeQuery("select * from user where status1='Approved'");
		ResultSet r=s.executeQuery("select * from userrequest ");
		return r;
	}
	public static ResultSet getData2(String sql) {
		// TODO Auto-generated method stub
		Connection con = connect();
		ResultSet rs = null;
		try{
			PreparedStatement ps = con.prepareStatement(sql);
			rs =  ps.executeQuery();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return rs;
	}
	public static int Register(String sql, UserBean ub) 
	{
	int i = 0;
	Connection con = connect();
	try {
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, ub.getUsername());
		ps.setString(2, ub.getPassword());
		ps.setString(3, ub.getDob());
		ps.setString(4, ub.getGender());
		ps.setString(5, ub.getEmailid());
		ps.setString(6, ub.getCity());
		ps.setString(7, ub.getAddress());
		i = ps.executeUpdate();
		ps.close();
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return i;
}
	}
	

