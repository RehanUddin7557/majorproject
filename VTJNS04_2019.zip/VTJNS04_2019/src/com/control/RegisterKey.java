package com.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.bean.SendEmailTLS;
import com.dao.Dao;
import com.dao.RandomeString;


/**
 * Servlet implementation class RegisterKey
 */
@WebServlet("/RegisterKey")
public class RegisterKey extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger log=Logger.getLogger(User.class);  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterKey() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter o = response.getWriter();
		String name=request.getParameter("username");
		String emailid=request.getParameter("emailid");
		HttpSession hs=request.getSession();
		hs.setAttribute("username", name);
		hs.setAttribute("emailid", emailid);
		int count=0;
		try {
			ResultSet r=Dao.getUser();
			while(r.next())
			{
				if(r.getString(5).equals(emailid))
				{
					count++;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(count!=0)
		{
		String otu=RandomeString.getSaltString();
		hs.setAttribute("otu", otu);
		String ootp=RandomeString.getSaltString();
		hs.setAttribute("checkotp", ootp);// checking otp with user entered otp
		SendEmailTLS.SendEmail(emailid,ootp);
		 getServletContext().getRequestDispatcher("/user.jsp").forward(
                 request, response);
	//	response.sendRedirect("EmailSendingServlet");
		}else{
			RequestDispatcher rd=request.getRequestDispatcher("Success.jsp?msg=<center>Invalid Account</center>&&to=index.jsp");
			o.println("alert('Please enter valid Details');");
			rd.forward(request, response);
		}
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
