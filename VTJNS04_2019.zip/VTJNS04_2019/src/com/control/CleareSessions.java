package com.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
/**
 * Servlet implementation class CleareSessions
 */
@WebServlet("/CleareSessions")
public class CleareSessions extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger log=Logger.getLogger(CleareSessions.class);
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CleareSessions() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession hs=request.getSession();
		MDC.put("UserId", (String)hs.getAttribute("emailid"));
		log.debug("User "+(String)hs.getAttribute("username")+" Logout Successfully ");
		
		hs.removeAttribute("username");
		hs.removeAttribute("emailid");
		hs.removeAttribute("otu");
		hs.removeAttribute("otp");
		
		response.sendRedirect("index.jsp");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
