package com.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;

import com.bean.SendEmailTLS;
import com.dao.Dao;

/**
 * Servlet implementation class User
 */
@WebServlet("/User")
public class User extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static Logger log=Logger.getLogger(User.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public User() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*PrintWriter o = response.getWriter();
		String uid = request.getParameter("emailid");
		String pwd = request.getParameter("password");
		HttpSession session = request.getSession();
		String sql = "select * from user where emailid='"+uid+"' and password='"+pwd+"'and status1='Approved'";
		System.out.println("sql is"+sql);
				if(Dao.checkUserLogin(sql)) {
					session.setAttribute("emailid", uid);
					response.sendRedirect("uhome.jsp");
				}	
			else {
				o.println("<script type=\"text/javascript\">");
				o.println("alert('Please Enter Valid Details.../Register Initially...');");
				o.println("window.location='user.jsp'</script>");
			}*/
		String otu=request.getParameter("otu");
		String otp=request.getParameter("otp");
		HttpSession hs=request.getSession();
		String ootu=(String)hs.getAttribute("otu");
		String ootp=(String)hs.getAttribute("checkotp");
	//	String sql="select * from user where status1='Approved'";
		if(otu.equals(ootu)&&otp.equals(ootp))
		{
			
			String s=(String) hs.getAttribute("emailid");
			//SendEmailTLS.SendEmail(s);
			MDC.put("UserId",s );
			log.debug("User "+s+" login successfully");
            
			response.sendRedirect("uhome.jsp");
		}
	}
	}
