package com.control;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.Dao;

/**
 * Servlet implementation class FDownload
 */
@WebServlet("/FDownload")
public class FDownload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FDownload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			String fid = request.getParameter("fid");
			System.out.println(fid);
			Connection con = Dao.connect();
			Statement st = con.createStatement();
			ResultSet r = st.executeQuery("select * from upload where fid ='"
					+ fid + "'");
			OutputStream o = response.getOutputStream();
			
			/*InputStream is = null;
	        OutputStream os = null;
			 if(rs.next()){
	                is = rs.getBinaryStream(5);
	            }
	            is = new FileInputStream(new File("D:\\java\\Student_img.jpg"));
	            os = new FileOutputStream("c:\\temp\\std_img.jpg");
	            byte[] content = new byte[1024];
	            int size = 0;
	            while((size = is.read(content)) != -1){
	                os.write(content, 0, size);
	            }
			
			*/
			
			if (r.next()) {
				response.setContentType(r.getString(6));
				System.out.println(r.getBytes(4));
				System.out.println(r.getBytes(5));
						o.write(r.getBytes(5));
				
			}
			o.flush();
			o.close();
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
