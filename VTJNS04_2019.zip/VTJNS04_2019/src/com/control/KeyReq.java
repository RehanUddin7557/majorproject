package com.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Dao;

/**
 * Servlet implementation class KeyReq
 */
@WebServlet("/KeyReq")
public class KeyReq extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public KeyReq() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter o = response.getWriter();
		HttpSession session=request.getSession();
		String uid=(String)session.getAttribute("emailid");
		String fname = request.getParameter("filename");
		String sname = request.getParameter("servername");
		System.out.println(fname);
		String fid = request.getParameter("fid");
		String sql = "select filename from upload where fid='" + fid + "'";
		sql = "select * from keyreq where fid='" + fid + "' and filename='"+fname+"' and userid='"+uid+"'";
		if (Dao.getData(sql) == true){
			o.println("<script type=\"text/javascript\">");
			o.println("alert('Already Made Request For Keys');");
			o.println("window.location='downloadf.jsp';</script>");
		} else {
			com.bean.KeyRecvBean kb = new com.bean.KeyRecvBean();
			kb.setEmailid(uid);
			
			kb.setFilename(fname);
			kb.setServername(sname);
			kb.setFid(fid);
			sql = "insert into keyreq values(?,?,?,?,?)";
			int i1 = Dao.sendRKeys(sql, kb);
			if(i1 > 0){
				o.println("<script type=\"text/javascript\">");
				o.println("alert('Key Request Sent Successfully');");
				o.println("window.location='downloadf.jsp';</script>");
			}else{
				o.println("<script type=\"text/javascript\">");
				o.println("alert('Keys request not sent');");
				o.println("window.location='downloadf.jsp';</script>");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
