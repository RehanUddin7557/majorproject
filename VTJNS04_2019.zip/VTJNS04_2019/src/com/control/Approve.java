package com.control;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.MDC;
import org.apache.log4j.Logger;

import com.bean.UserBean;
import com.dao.Dao;

/**
 * Servlet implementation class Approve
 */
@WebServlet("/Approve")
public class Approve extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Approve() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*String s=request.getParameter("emailid");
		System.out.println("value from html"+s);
		try {
			boolean f=Dao.updateUser(s);
			System.out.println("boolean in sevlet"+f);
			if(!f) {
				System.out.println("Approved");
				response.sendRedirect("userdetails.jsp");
			}else {
				System.out.println("failed");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		String name = request.getParameter("emailid");
		String sql = "select * from user where emailid='" + name + "'";
		ResultSet rs = Dao.getData2(sql);
		String sql1 = "insert into userrequest values(?,?,?,?,?,?,?)";
		UserBean ub = new UserBean();
		try {
			while (rs.next()) {
				ub.setUsername(rs.getString(1));
				ub.setPassword(rs.getString(2));
				ub.setDob(rs.getString(3));
				ub.setGender(rs.getString(4));
				ub.setEmailid(rs.getString(5));
				ub.setCity(rs.getString(6));
				ub.setAddress(rs.getString(7));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int i = Dao.Register(sql1, ub);
		if (i == 1) {
			MDC.put("UserID", "Admin");
		//	log.debug("Admin approve the Member Request");
			sql = "update user set status1='Approved' where emailid='" + name + "'";
			int k = Dao.update(sql);
			if (k == 1)
				response.sendRedirect("AddSuccess1.jsp?name=Member");
		} else {
			response.sendRedirect("RegisterError.jsp");
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
