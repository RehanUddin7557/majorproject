package com.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.Dao;

/**
 * Servlet implementation class Server
 */
@WebServlet("/Server")
public class Server extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Server() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
		String uid = request.getParameter("emailid");
		String pwd = request.getParameter("password");
		HttpSession session = request.getSession();
	    System.out.println("emailid and password"+uid+pwd);	
		String sql = "select * from serverrequest where emailid='"+uid+"' and password='"+pwd+"'and approval='Approved'";
		System.out.println("sql is"+sql);
				if(Dao.checkUserLogin(sql)) {
					session.setAttribute("emailid", uid);
					response.sendRedirect("serverhome.jsp");
				}	
			else {
				pw.println("<script type=\"text/javascript\">");
				pw.println("alert('Please Enter Valid Details.../Register Initially...');");
				pw.println("window.location='server.jsp'</script>");
			}
		} 
	}
